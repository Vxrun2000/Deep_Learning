
import numpy as np

class Sgd:
    def __init__(self, learning_rate):
        self.learning_rate = learning_rate
    
    def calculate_update(self, weight_tensor, gradient_tensor):
        return weight_tensor - self.learning_rate * gradient_tensor
        

class SgdWithMomentum:
    def __init__(self, learning_rate, momentum_rate):
        self.learning_rate = learning_rate
        self.momentum_rate = momentum_rate
        self.velocity = None
    
    def calculate_update(self, weight_tensor, gradient_tensor):
        # Initialize velocity on first call
        if self.velocity is None:
            self.velocity = np.zeros_like(weight_tensor)
        
        # Update velocity: v_t = momentum * v_{t-1} + learning_rate * gradient
        self.velocity = self.momentum_rate * self.velocity + self.learning_rate * gradient_tensor
        
        # Update weights: weights = weights - velocity
        return weight_tensor - self.velocity


class Adam:
    def __init__(self, learning_rate, mu, rho):
        self.learning_rate = learning_rate
        self.mu = mu              # β1 (first moment decay rate)
        self.rho = rho            # β2 (second moment decay rate)
        self.m = None             # First moment estimate
        self.v = None             # Second moment estimate
        self.t = 0                # Time step counter
        self.epsilon = np.finfo(float).eps      # Small constant for numerical stability
    
    def calculate_update(self, weight_tensor, gradient_tensor):
        # Initialize moments on first call
        if self.m is None:
            self.m = np.zeros_like(weight_tensor)
        if self.v is None:
            self.v = np.zeros_like(weight_tensor)
        
        # Increment time step
        self.t += 1
        
        # Update biased first moment estimate
        self.m = self.mu * self.m + (1 - self.mu) * gradient_tensor
        
        # Update biased second raw moment estimate
        self.v = self.rho * self.v + (1 - self.rho) * (gradient_tensor ** 2)
        
        # Compute bias-corrected first moment estimate
        m_hat = self.m / (1 - self.mu ** self.t)
        
        # Compute bias-corrected second raw moment estimate
        v_hat = self.v / (1 - self.rho ** self.t)
        
        # Update weights
        update = self.learning_rate * m_hat / (np.sqrt(v_hat) + self.epsilon)
        return weight_tensor - update